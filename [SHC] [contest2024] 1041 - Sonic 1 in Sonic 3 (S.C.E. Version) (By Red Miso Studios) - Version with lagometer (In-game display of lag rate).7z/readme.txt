Sonic 1 in Sonic 3 (S.C.E. Version) with lagometer (In-game display of lag rate)

There are two ROMs here.

S1(LAG).gen	- The original Sonic The Hedgehog (1991)
S1S3(LAG).gen	- Sonic 1 in Sonic 3 (S.C.E. Version)

You can take a look and compare the performance of the two games. You'll see a bar of random tiles on the right side. The lower it goes, the slower the game is running at the moment.


Sonic Hacking Contest page:
https://shc.zone/entries/contest2024/1041

Visit our pages to keep up with all the news:
Discord: https://discords.com/servers/redmisostudios
BlueSky: https://bsky.app/profile/redmiso.studio
YouTube: https://www.youtube.com/@RedMisoStudios
Twitter: https://x.com/HardLine_Team
Website: https://redmiso.studio/

Russian language only:
Telegram channel: https://t.me/red_miso_studios
VK: https://vk.com/red_miso_studios

Base Sonic Clean Engine (S.C.E.) on GitHub (without Sonic 1):
https://github.com/TheBlad768/Sonic-Clean-Engine-S.C.E.-
https://github.com/TheBlad768/Sonic-Clean-Engine-S.C.E.-Extended-
